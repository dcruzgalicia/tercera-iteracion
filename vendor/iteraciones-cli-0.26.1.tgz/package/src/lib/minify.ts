import { logWarning } from './logger.js';

const BIN = 'minify';

let available: boolean | null = null;
let warnedMissing = false;
let warnedFailure = false;

async function minifyAvailable(): Promise<boolean> {
  if (available !== null) return available;
  try {
    const proc = Bun.spawn([BIN, '-l'], { stdout: 'ignore', stderr: 'ignore' });
    available = (await proc.exited) === 0;
  } catch {
    available = false;
  }
  return available;
}

export async function checkMinify(): Promise<{ label: string; ok: boolean; detail?: string; warn: boolean }> {
  const ok = await minifyAvailable();
  return {
    label: 'minify instalado',
    ok,
    warn: true,
    detail: ok
      ? 'minifica el HTML de la salida'
      : 'no encontrado en PATH. Instálalo desde https://github.com/tdewolff/minify (por ejemplo: brew install minify)',
  };
}

export async function minifyHtml(html: string): Promise<string> {
  if (!(await minifyAvailable())) {
    if (!warnedMissing) {
      logWarning('minify no está en PATH; el HTML sale sin minificar. Instálalo con `brew install minify`', 'html');
      warnedMissing = true;
    }
    return html;
  }

  const proc = (() => {
    try {
      return Bun.spawn([BIN, '--type', 'html', '--html-keep-quotes'], {
        stdin: new Blob([html]),
        stdout: 'pipe',
        stderr: 'pipe',
      });
    } catch {
      return undefined;
    }
  })();
  if (proc === undefined) {
    if (!warnedMissing) {
      logWarning('minify no está en PATH; el HTML sale sin minificar. Instálalo con `brew install minify`', 'html');
      warnedMissing = true;
    }
    return html;
  }

  const [salida, error] = await Promise.all([new Response(proc.stdout).text(), new Response(proc.stderr).text()]);
  const code = await proc.exited;
  if (code !== 0) {
    if (!warnedFailure) {
      logWarning(`minify falló; el HTML sale sin minificar. stderr: ${error.trim()}`, 'html');
      warnedFailure = true;
    }
    return html;
  }
  return salida;
}
