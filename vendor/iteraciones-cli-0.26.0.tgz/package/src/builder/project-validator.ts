import { isAbsolute, join } from 'node:path';
import type { SiteConfig } from '../config/config-schema.js';

interface ValidationIssue {
  severity: 'error' | 'warning';
  message: string;
}

export const MISSING_TITLE_WARNING: ValidationIssue = {
  severity: 'warning',
  message: 'no tiene título en el frontmatter; se usará "Sin título"',
};

const KNOWN_FRONTMATTER_FIELDS = [
  'title',
  'creator',
  'subject',
  'description',
  'publisher',
  'contributor',
  'date',
  'identifier',
  'source',
  'language',
  'relation',
  'coverage',
  'rights',
  'subtitle',
  'slug',
  'toc',
  'keywords',
  'license',
  'doi',
  'isbn',
  'abstract',
  'site-title',
  'tagline',
  'theme',
  'accent',
  'css',
  'extratitle',
  'frontispiece',
  'titlehead',
  'collectionCreator',
  'collectionCreatorPrefix',
  'dedication',
  'uppertitleback',
  'lowertitleback',
  'colophon',
  'titleImage',
  'publisherImage',
  'startpaper',
  'frontCover',
  'backCover',
  'coverColor',
  'courtesyPage',
  'type',
  'files',
  'filter',
  'order',
  'name',
  'links',
  'pages',
  'lineLength',
  'letterhead',
  'letterheadHeight',
  'image',
  'placement',
];

export const LIST_FILTER_KEYS = ['type', 'creator', 'date', 'keyword', 'path'] as const;

export const LIST_ORDERS = ['date-desc', 'date-asc', 'title-asc', 'title-desc', 'creator-asc'] as const;

const LIST_TYPES = ['file', 'collection', 'creator', 'list'] as const;

const SLUG_MANUAL_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

const STRING_FRONTMATTER_FIELDS = ['title', 'subtitle', 'date', 'image'];

const DATE_ISO_RE = /^\d{4}-\d{2}-\d{2}$/;

function validateStringFields(parsed: Record<string, unknown>): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  for (const field of STRING_FRONTMATTER_FIELDS) {
    const value = parsed[field];
    if (value !== undefined && typeof value !== 'string') {
      issues.push({ severity: 'error', message: `frontmatter: "${field}" debe ser un texto (string), se recibió ${typeof value}` });
    }
  }
  return issues;
}

function validateCreatorField(parsed: Record<string, unknown>): ValidationIssue[] {
  const creator = parsed.creator;
  if (creator !== undefined && typeof creator !== 'string' && !(Array.isArray(creator) && creator.every((a) => typeof a === 'string'))) {
    return [{ severity: 'error', message: 'frontmatter: "creator" debe ser un texto o una lista de textos' }];
  }
  return [];
}

function validateDateFormat(parsed: Record<string, unknown>): ValidationIssue[] {
  const date = parsed.date;
  if (typeof date === 'string' && date.trim() !== '' && !DATE_ISO_RE.test(date.trim())) {
    return [{ severity: 'warning', message: 'frontmatter: "date" no usa el formato ISO YYYY-MM-DD; se mostrará tal cual' }];
  }
  return [];
}

function validateEmptyFields(parsed: Record<string, unknown>): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  for (const [key, value] of Object.entries(parsed)) {
    if (!KNOWN_FRONTMATTER_FIELDS.includes(key)) continue;
    if (value === undefined) continue;
    if (value === null || value === '' || (Array.isArray(value) && value.length === 0)) {
      issues.push({ severity: 'warning', message: `frontmatter: "${key}" está vacío; se omitirá del metadato` });
    }
  }
  return issues;
}

function validateUnknownFields(parsed: Record<string, unknown>): ValidationIssue[] {
  const unknown = Object.keys(parsed).filter((key) => !KNOWN_FRONTMATTER_FIELDS.includes(key));
  if (unknown.length > 0) {
    return [{ severity: 'warning', message: `campos de frontmatter ignorados por el pipeline: ${unknown.join(', ')}` }];
  }
  return [];
}

function validateSlugField(parsed: Record<string, unknown>): ValidationIssue[] {
  const slug = typeof parsed.slug === 'string' ? parsed.slug.trim() : undefined;
  if (slug && !SLUG_MANUAL_RE.test(slug)) {
    return [
      { severity: 'error', message: `slug inválido: "${slug}" — usa solo minúsculas, números y guiones (sin espacios, acentos ni guiones extremos)` },
    ];
  }
  return [];
}

function validateCollectionType(parsed: Record<string, unknown>): ValidationIssue[] {
  const issues: ValidationIssue[] = [];

  if (parsed.creator !== undefined) {
    issues.push({
      severity: 'error',
      message: 'frontmatter: "type: collection" usa "collectionCreator", no "creator" — renombra el campo',
    });
  }
  const files = parsed.files;
  if (files === undefined) {
    issues.push({ severity: 'error', message: 'frontmatter: "type: collection" requiere el campo "files"' });
    return issues;
  }
  if (!Array.isArray(files) || !files.every((f) => typeof f === 'string')) {
    issues.push({ severity: 'error', message: 'frontmatter: "files" debe ser una lista de textos (strings)' });
  }
  return issues;
}

function validateCreatorType(parsed: Record<string, unknown>): ValidationIssue[] {
  const name = parsed.name;
  const title = parsed.title;
  if (name !== undefined && typeof name !== 'string') {
    return [{ severity: 'error', message: 'frontmatter: "name" debe ser un texto (string)' }];
  }
  if (name === undefined && (title === undefined || typeof title !== 'string' || title === '')) {
    return [{ severity: 'error', message: 'frontmatter: "type: creator" requiere el campo "name" (o "title")' }];
  }
  const links = parsed.links;
  if (links === undefined) return [];
  if (!Array.isArray(links)) {
    return [{ severity: 'error', message: 'frontmatter: "links" debe ser una lista de objetos con "name" y "url"' }];
  }
  for (const link of links) {
    if (
      typeof link !== 'object' ||
      link === null ||
      typeof (link as Record<string, unknown>).name !== 'string' ||
      typeof (link as Record<string, unknown>).url !== 'string'
    ) {
      return [{ severity: 'error', message: 'frontmatter: "links" debe ser una lista de objetos con "name" (string) y "url" (string)' }];
    }
  }
  return [];
}

function validateInterventionType(parsed: Record<string, unknown>): ValidationIssue[] {
  const pages = parsed.pages;
  if (pages !== undefined && (typeof pages !== 'number' || !Number.isInteger(pages) || pages < 1)) {
    return [{ severity: 'error', message: 'frontmatter: "pages" debe ser un entero positivo (1, 2, 3, ...)' }];
  }
  const lineLength = parsed.lineLength;
  if (lineLength !== undefined && (typeof lineLength !== 'number' || lineLength <= 0 || lineLength > 1)) {
    return [{ severity: 'error', message: 'frontmatter: "lineLength" debe ser un número entre 0 y 1 (ej. 0.5, 0.7, 1)' }];
  }
  return validateLetterheadHeight(parsed.letterheadHeight);
}

function validateLetterheadHeight(value: unknown): ValidationIssue[] {
  if (value === undefined) return [];
  const numero = typeof value === 'number' ? value : typeof value === 'string' ? Number.parseFloat(value) : Number.NaN;
  const formato = typeof value === 'number' || (typeof value === 'string' && /^\s*[\d.]+\s*(mm|cm|pt|in)?\s*$/i.test(value));
  if (formato && Number.isFinite(numero) && numero > 0) return [];
  return [{ severity: 'error', message: 'frontmatter: "letterheadHeight" debe ser una medida positiva, por ejemplo "5cm", "50mm" o "2in"' }];
}

function validateListDate(value: unknown): ValidationIssue[] {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    return [{ severity: 'error', message: 'frontmatter: "filter.date" debe ser un mapa con "from" y/o "to"' }];
  }
  const issues: ValidationIssue[] = [];
  for (const [borde, fecha] of Object.entries(value as Record<string, unknown>)) {
    if (borde !== 'from' && borde !== 'to') {
      issues.push({
        severity: 'error',
        message: `frontmatter: "filter.date" no tiene "${borde}"; los bordes son: from, to`,
      });
      continue;
    }
    if (typeof fecha !== 'string' || !DATE_ISO_RE.test(fecha.trim())) {
      issues.push({
        severity: 'error',
        message: `frontmatter: "filter.date.${borde}" debe ser una fecha ISO (YYYY-MM-DD)`,
      });
    }
  }
  return issues;
}

function validateListFilter(filter: unknown): ValidationIssue[] {
  if (typeof filter !== 'object' || filter === null || Array.isArray(filter)) {
    return [{ severity: 'error', message: 'frontmatter: "filter" debe ser un mapa con los criterios de selección' }];
  }
  const issues: ValidationIssue[] = [];
  for (const [key, value] of Object.entries(filter as Record<string, unknown>)) {
    if (!(LIST_FILTER_KEYS as readonly string[]).includes(key)) {
      issues.push({
        severity: 'error',
        message: `frontmatter: "filter" no tiene el criterio "${key}"; los criterios son: ${LIST_FILTER_KEYS.join(', ')}`,
      });
      continue;
    }
    if (key === 'type') {
      if (typeof value !== 'string' || !(LIST_TYPES as readonly string[]).includes(value)) {
        issues.push({
          severity: 'error',
          message: `frontmatter: "filter.type" debe ser uno de: ${LIST_TYPES.join(', ')}`,
        });
      }
      continue;
    }
    if (key === 'date') {
      issues.push(...validateListDate(value));
      continue;
    }
    if (typeof value !== 'string') {
      issues.push({ severity: 'error', message: `frontmatter: "filter.${key}" debe ser un texto` });
    }
  }
  return issues;
}

function validateMenuType(parsed: Record<string, unknown>): ValidationIssue[] {
  if (parsed.links === undefined) return [];
  const links = parsed.links;
  if (!Array.isArray(links)) {
    return [{ severity: 'error', message: 'frontmatter: "links" debe ser una lista de enlaces con "name" y "url"' }];
  }
  const invalidos = links.filter(
    (l) =>
      typeof l !== 'object' ||
      l === null ||
      typeof (l as Record<string, unknown>).name !== 'string' ||
      typeof (l as Record<string, unknown>).url !== 'string',
  );
  if (invalidos.length > 0) {
    return [{ severity: 'error', message: 'frontmatter: cada enlace de "links" necesita "name" y "url" de texto' }];
  }
  return [];
}

function validateAnnouncementType(parsed: Record<string, unknown>): ValidationIssue[] {
  const placement = parsed.placement;
  if (placement === undefined || placement === 'top' || placement === 'bottom') return [];
  return [{ severity: 'warning', message: `frontmatter: "placement" debe ser "top" o "bottom"; se usa "top"` }];
}

function validateListType(parsed: Record<string, unknown>): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  if (parsed.filter !== undefined) issues.push(...validateListFilter(parsed.filter));
  const order = parsed.order;
  if (order !== undefined && !(LIST_ORDERS as readonly string[]).includes(String(order))) {
    issues.push({
      severity: 'error',
      message: `frontmatter: "order" debe ser uno de: ${LIST_ORDERS.join(', ')}`,
    });
  }
  return issues;
}

function validateTypeField(parsed: Record<string, unknown>): ValidationIssue[] {
  const type = parsed.type;
  if (type === undefined) return [];
  const tipos = ['file', 'collection', 'creator', 'intervention', 'list', 'menu', 'announcement'];
  if (!tipos.includes(String(type))) {
    return [{ severity: 'error', message: `frontmatter: "type" debe ser ${tipos.map((t) => `"${t}"`).join(', ')}` }];
  }
  if (type === 'collection') return validateCollectionType(parsed);
  if (type === 'creator') return validateCreatorType(parsed);
  if (type === 'intervention') return validateInterventionType(parsed);
  if (type === 'list') return validateListType(parsed);
  if (type === 'menu') return validateMenuType(parsed);
  if (type === 'announcement') return validateAnnouncementType(parsed);
  return [];
}

export function validateFrontmatterFields(parsed: Record<string, unknown>): ValidationIssue[] {
  return [
    ...validateStringFields(parsed),
    ...validateCreatorField(parsed),
    ...validateDateFormat(parsed),
    ...validateEmptyFields(parsed),
    ...validateUnknownFields(parsed),
    ...validateSlugField(parsed),
    ...validateTypeField(parsed),
  ];
}

const DICTUM_WIDTH_RE = /^:::\s*\{[^}]*\.dictum[^}]*\bwidth\s*=\s*([0-9]*\.?[0-9]+)/;
const DICTUM_WIDTH_MIN = 0.1;
const DICTUM_WIDTH_MAX = 1.0;

interface DictumWidthWarning {
  line: number;
  value: number;
}

function scanDictumWidths(text: string, lineOffset: number, skipFences: boolean): DictumWidthWarning[] {
  const hits: DictumWidthWarning[] = [];
  let inCode = false;
  let lineNum = 0;
  for (const rawLine of text.split('\n')) {
    lineNum++;
    const trimmed = rawLine.trimEnd();
    if (skipFences && /^(```|~~~)/.test(trimmed)) {
      inCode = !inCode;
      continue;
    }
    if (inCode) continue;
    const m = DICTUM_WIDTH_RE.exec(trimmed);
    if (m?.[1]) {
      const num = Number.parseFloat(m[1]);
      if (!Number.isNaN(num) && (num < DICTUM_WIDTH_MIN || num > DICTUM_WIDTH_MAX)) {
        hits.push({ line: lineNum + lineOffset, value: num });
      }
    }
  }
  return hits;
}

export function dictumWidthWarnings(body: string, lineOffset = 0): DictumWidthWarning[] {
  return scanDictumWidths(body, lineOffset, true);
}

export function dictumWidthWarningsInYaml(yaml: string, lineOffset = 0): DictumWidthWarning[] {
  return scanDictumWidths(yaml, lineOffset, false);
}

export function dictumWidthWarningsMessage(warnings: DictumWidthWarning[]): string {
  return warnings
    .map(
      (w) =>
        `línea ${w.line}: dictum width=${w.value} fuera de rango (${DICTUM_WIDTH_MIN}–${DICTUM_WIDTH_MAX}); se usa ${DICTUM_WIDTH_MIN} por defecto`,
    )
    .join('; ');
}

export function validateConfigRules(config: SiteConfig): ValidationIssue[] {
  const issues: ValidationIssue[] = [];

  if (config.bundle === true && config.format?.markdown?.generate !== true) {
    issues.push({
      severity: 'error',
      message: 'bundle: true requiere "format.markdown.generate: true" — actívalo para que dist/files se pueda reconstruir',
    });
  }
  return issues;
}

export async function validateConfigFilePaths(cwd: string, config: SiteConfig): Promise<ValidationIssue[]> {
  const issues: ValidationIssue[] = [];
  for (const rel of config.luaFilters ?? []) {
    if (!(await Bun.file(join(cwd, rel)).exists())) {
      issues.push({ severity: 'warning', message: `luaFilters: "${rel}" no encontrado en el proyecto` });
    }
  }
  for (const key of ['bibliography', 'csl'] as const) {
    const rel = config[key];
    if (!rel) continue;
    const abs = isAbsolute(rel) ? rel : join(cwd, rel);
    if (!(await Bun.file(abs).exists())) {
      issues.push({ severity: 'error', message: `${key}: "${rel}" no encontrado en el proyecto` });
    }
  }
  return issues;
}
